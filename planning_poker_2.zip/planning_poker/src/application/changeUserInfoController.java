package application;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class changeUserInfoController {

    @FXML
    private TextField nameField;

    @FXML
    private TextField emailField;

    @FXML
    private TextField addressField;

    @FXML
    private TextField phoneField;

    // Add methods to handle events or initialize data
}
