package application;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.event.ActionEvent;

public class reqleave {

    @FXML
    private Button dateButton;

    @FXML
    private Button reasonButton;

    @FXML
    private void handleDateAction(ActionEvent event) {
        // Logic for what happens when the Date button is clicked
    }

    @FXML
    private void handleReasonAction(ActionEvent event) {
        // Logic for what happens when the Reason button is clicked
    }

    // Additional methods and logic for the Request Leave scene can be added here
}
