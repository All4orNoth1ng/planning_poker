package application;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.event.ActionEvent;

public class prvcsrc {

    @FXML
    private Button socialSecurityButton;
    @FXML
    private Button directDepositButton;
    @FXML
    private Button bankAccountButton;

    @FXML
    private void handleSocialSecurityAction(ActionEvent event) {
        // Logic for what happens when the Social Security button is clicked
    }

    @FXML
    private void handleDirectDepositAction(ActionEvent event) {
        // Logic for what happens when the Direct Deposit button is clicked
    }

    @FXML
    private void handleBankAccountAction(ActionEvent event) {
        // Logic for what happens when the Bank Account button is clicked
    }
}
