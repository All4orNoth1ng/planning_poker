package application;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;
import javafx.event.ActionEvent;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class helpandsupport {

    @FXML TextField nameField;

    @FXML TextField emailField;

    @FXML TextArea messageField;

    @FXML
    private Button sendMessageButton;
    
    private Button backButton;
    
    
    private SceneController sceneController = new SceneController(); 

    @FXML void handleSendMessage(ActionEvent event) {
        String name = nameField.getText();
        String email = emailField.getText();
        String message = messageField.getText();

        if (!name.isEmpty() && !email.isEmpty() && !message.isEmpty()) {
        	// we have the option to adjust the location of the user messages file saving 
            try (BufferedWriter writer = new BufferedWriter(new FileWriter("/Users/abhirupvijaygunakar/eclipse-workspace/planning_poker/UserMessages/" + name + ".txt"))
) {
                writer.write("Name: " + name + "\n");
                writer.write("Email: " + email + "\n");
                writer.write("Message: " + message);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
        }
    }

    @FXML
    private void handleBack(ActionEvent event) {
        try {
            sceneController.switchToUserMenu(event);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
