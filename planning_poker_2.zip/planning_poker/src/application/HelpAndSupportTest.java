package application;

import org.junit.jupiter.api.Test;

import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import static org.junit.jupiter.api.Assertions.*;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.File;
import java.io.IOException;

public class HelpAndSupportTest {

    private helpandsupport support;
    private String testFileName;

    @BeforeEach
    public void setUp() {
        support = new helpandsupport();

        // Set the fields
        support.nameField = new TextField();
        support.emailField = new TextField();
        support.messageField = new TextArea();

        // Set test data
        support.nameField.setText("Test Name");
        support.emailField.setText("test@example.com");
        support.messageField.setText("Test message");

        // Set the test file name (assuming the handleSendMessage method uses this format)
        testFileName = "/Users/abhirupvijaygunakar/eclipse-workspace/planning_poker/UserMessages/Test Name.txt";
    }

    @Test
    public void testMessageWriting() throws IOException {
        // Invoke the method
        support.handleSendMessage(null);

        // Check if the file is created
        File file = new File(testFileName);
        assertTrue(file.exists());

        // Check the content of the file
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            assertEquals("Name: Test Name", reader.readLine());
            assertEquals("Email: test@example.com", reader.readLine());
            assertEquals("Message: Test message", reader.readLine());
        }
    }

    @AfterEach
    public void tearDown() {
        // Clean up: delete the test file
        File file = new File(testFileName);
        if (file.exists()) {
            file.delete();
        }
    }
}
